<h1>Bedrock greenscreen pack</h1>
A simple Minecraft Bedrock resource pack that make certain things completely green or blue for your greenscreen needs.
<h2>Blocks changed:</h2>
<ul>
  <li>Green concrete, to a brighter shade of green. Also makes every pixel the same shade of green</li>
  <li>Blue concrete, makes  all the pixels the same shade of blue</li>
  <li>Makes some paintings green, and others blue. I have tried to make it as even in the amount of colours possible.</li>
</ul>

The reason I included both green and blue, is so that if the object you are using contains blue/green things you can use the other colour.
