# piglin-to-pigman-mcbe
This Minecraft Bedrock resource pack turns the 1.16 Zombie Piglins into Zombie Pigmen from pre 1.16
