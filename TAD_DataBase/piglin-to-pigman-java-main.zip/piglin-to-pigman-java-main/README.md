# piglin-to-pigman-java
This Minecraft Java edition resource pack turns the 1.16 Zombie Piglins into Zombie Pigmen from pre 1.16

<b>You must be using optifine to also get the old mob model, otherwise you will see the piman texture with the piglin model!</b>
You can get optifine here: https://optifine.net/
