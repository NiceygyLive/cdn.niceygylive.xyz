# Clear chat resource pack for Minecraft Bedrock edition
This resource pack removes the black background from the chat on Minecraft Bedrock edition.
